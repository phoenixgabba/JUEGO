# ACAMPADA VALÈNCIA — ampliación por hitos

## Hito 0 — Base del Día 1 heredada [funcionalidad existente comprobada]

- [x] Conversaciones con Alba, Joan y Mar; asamblea con decisión; recogida de lona, varillas y piquetas; montaje interactivo en cuatro fases; llegada caminando de dos residentes; tienda con capacidad de dos personas; constitución provisional de Organización en D junto a H; HUD, diario, pausa y guardado local.
- [x] Se conserva el proyecto existente de Godot 4/GDScript, las escenas, el arte ya integrado y las pruebas del recorrido. El juego empieza casi vacío; ninguna persona aparece automáticamente por construir una tienda.
- [ ] Actualizar la plaza aproximada actual: la entrega heredada aún no satisface el nuevo requisito de escala, cámara, navegación amplia ni reconstrucción espacial final del croquis.

## Hito 1 — Plaza final explorable y circulación segura

- [ ] Recrear la Plaça de l'Ajuntament en pixel art cenital original y a escala espacial legible, como mapa amplio transitable con cámara, arquitectura, mobiliario, sombras y capas; sustituir el fondo único como límite del mundo, no borrar los recursos existentes que sigan sirviendo.
- [ ] Respetar la distribución final del croquis: Ayuntamiento arriba; B arriba a la izquierda; C y E abajo a la izquierda; A a la derecha; D abajo a la derecha; H/Plaza 15M a la derecha y la fuente después de H. Organización se sitúa en D junto a H. Redes ocupa B. Recursos, Cocina, Seguridad y Recogida siguen el eje central de arriba abajo. Punto Violeta, Médico y Cultura están arriba a la derecha. Información queda en el acceso. Respetar las filas de tiendas; las comisiones sin ubicación pueden operar sin carpa. Evitar bloques de color.
- [ ] Separar hitboxes de la ilustración. Mantener libres los caminos principales y un acceso exterior practicable a cada puesto. No permitir construir sobre personajes ni cerrar rutas. Al completar construcción y al migrar una partida antigua, llevar al jugador a suelo seguro.
- [ ] Probar las salidas y los accesos de cada puesto, los límites y obstáculos del mapa, la construcción en los bordes de rutas, la reubicación segura y la recuperación de la partida heredada; comprobar que el jugador nunca quede atrapado.

## Hito 2 — Plaza viva, crecimiento orgánico y capítulos

- [ ] Empezar casi en vacío y hacer que las conversaciones, asambleas, materiales y construcciones cambien físicamente el espacio. Las tiendas aportan capacidad, no generan residentes automáticos. Visitantes/residentes llegan caminando, pueden ocupar plazas disponibles, colaborar, seguir rutinas y producir necesidades.
- [ ] Hacer que las comisiones nazcan de necesidades, población, recursos, conversaciones y acuerdos; evitar desbloqueos rígidos que obliguen a repetir tareas. Mostrar acuerdos y consecuencias en el mundo y el diario.
- [ ] Añadir días y capítulos, rutinas de NPC, humor, eventos y misiones secundarias con alternativas que no bloqueen la historia. Gestionar y guardar vida, energía, bienestar, población, caja colectiva, recursos y respeto.
- [ ] Añadir visita médica para recuperar vida y Punto Violeta informativo/derivador, ambos sin minijuego ni cuestionarios.

## Hito 3 — Diecisiete comisiones y quince mecánicas distintas

- [ ] Implementar Organización, incluida la gestión de turnos, actas/acuerdos y documentos legales ficticios.
- [ ] Implementar Cocina con preparación de platos mediante selección/arrastre de ingredientes y tiempos, y efecto en recursos y bienestar.
- [ ] Implementar Punto de recogida con clasificación y arrastre de donaciones hacia sus destinos, cambiando el inventario colectivo.
- [ ] Implementar Inventario con recuento y asignación concreta de materiales a necesidades, evitando pérdidas y reflejando las existencias.
- [ ] Implementar Información con atención de visitantes y orientación de rutas/servicios según las necesidades presentes.
- [ ] Implementar Comunicación/prensa con preparación de una noticia y verificación de sus fuentes antes de difundirla.
- [ ] Implementar Redes con una publicación social de alcance comunitario en la que los datos deben verificarse; mostrar consecuencias de lo difundido.
- [ ] Implementar Accesibilidad con trazado de rutas practicables que mantengan pasos continuos y lleguen a los destinos sin barreras.
- [ ] Implementar Toldos/barricadas con montaje visual y orientación segura de coberturas y perímetros sin cerrar rutas.
- [ ] Implementar Asistencia médica como atención y recuperación de vida, sin minijuego.
- [ ] Implementar Punto Violeta como atención informativa, segura y con derivaciones, sin minijuego.
- [ ] Implementar Cultura con preparación y realización de talleres/actividades cuyo resultado cambie la participación o el bienestar.
- [ ] Implementar Seguridad con prevención de riesgos mediante detección y tratamiento situacional de peligros, no mediante cuestionario.
- [ ] Implementar Limpieza con recogida y clasificación de residuos para reciclaje/restos, y efecto visible en la plaza.
- [ ] Implementar Integración con recepción de nuevas personas, asignación voluntaria de tareas y apoyo a su llegada.
- [ ] Implementar Convivencia con mediación de conflictos y búsqueda de acuerdos, evitando respuestas binarias de cuestionario.
- [ ] Implementar Tesorería con registro de caja, ingresos y gastos, decisiones de presupuesto y consecuencias.
- [ ] Las 15 comisiones distintas de Asistencia médica y Punto Violeta tienen mecánicas jugables propias, visuales y conectadas a consecuencias; no reemplazarlas por botones ficticios, cuestionarios ni barras intercambiables.

## Hito 4 — Negociación, consecuencias y finales

- [ ] Al alcanzar 1.000 de respeto, habilitar preparación y una mesa de negociación con decisiones jugables y más de un final. El umbral se puede alcanzar mediante distintas contribuciones sin exigir una repetición única obligatoria.
- [ ] Persistir la progresión, el capítulo, acuerdos, comisiones, habitantes, recursos, valores y final; al cargar una partida antigua, aplicar valores seguros por defecto, conservar lo compatible y no ubicar al jugador dentro de un obstáculo.

## Hito 5 — Calidad y entrega verificada

- [ ] Mantener una arquitectura modular Godot 4/GDScript, sprites/elementos reutilizables, animación de personajes, sonido original útil, controles de escritorio y táctiles, diario, mapa, guardado automático y rendimiento razonable.
- [ ] Reprobar la ruta heredada que siga vigente y añadir pruebas acotadas de circulación, construcción, carga/migración, asignación de residentes solo al ocupar capacidad, aparición por necesidades, mecánicas, negociación y desenlaces. Distinguir pruebas nativas/simuladas de aceptación en iPhone o navegador real.
- [ ] Entregar la fuente del mismo proyecto y una versión jugable guardada. No afirmar publicada la versión pública salvo que se haya autorizado y confirmado por separado.

## Alcance de esta continuación

Los hitos 1–5 siguen pendientes hasta implementarse y probarse en el proyecto. El Hito 0 describe solo el recorrido Día 1 ya existente: no declara que el mapa final, las 17 comisiones, el sistema de días/capítulos ni los finales estén ya realizados.

## Evidencia de la continuación (22 de noviembre de 2026)

- `npm run check` termina con `ok:true` y `outcomeChecks:1`; pasan el recorrido del Día 1, cámara/mapa mayor, movimiento de teclado y táctil, montaje, llegada caminando de dos residentes que ocupan plazas disponibles, guardado/migración v1-v3 y las cuatro salidas de la primera tienda. Construir la tienda solo aporta capacidad, sin aumentar la población automáticamente. La prueba añade hitboxes decorativas, construcción sobre una jardinera, reubicación `safe_spawn` y conectividad desde el acceso hasta NPC, materiales, eje central, D, H y la zona transitable junto a la fuente.
- Se capturó con Godot 4.7.2 y renderizador GL Compatibility (llvmpipe) en escritorio 1280×720 y retrato 390×844. Es evidencia nativa de render, no aceptación en un iPhone ni prueba de interacción en navegador real.
- El nuevo fondo `assets/acampada/valencia_pixel_map_topdown_pixel.png` mejora la lectura cenital y mantiene la plaza sin tiendas al inicio; sigue siendo una ilustración detallada, no pixel art estricto de 16 bits. Se añadieron hitboxes estáticas aproximadas para jardineras/bancos y márgenes de paso/construcción, pero la cobertura no es exhaustiva ni se ha verificado cada acceso de cada puesto; el mundo continúa basado en un fondo único. El Hito 1 permanece abierto.
- `npm run preview:build` y `npm run preview:status` terminan en `ready`; el puerto de Preview responde con redirección al export actual. No se ha verificado la carga WASM/interacción en navegador ni en un dispositivo iPhone.
- Los días/capítulos posteriores, las 17 comisiones, negociación y finales no están implementados todavía; permanecen abiertos en los Hitos 2–4. No se ha publicado el juego.
