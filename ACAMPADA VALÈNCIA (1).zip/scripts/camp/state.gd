extends RefCounted
class_name CampState

const SAVE_PATH := "user://acampada-day1-v1.json"
const SAVE_VERSION := 3
const SAFE_START := Vector2(1152, 1320)

var phase := "talk"
var talked := {"Alba": false, "Joan": false, "Mar": false}
var collected := {"lona": false, "varillas": false, "piquetas": false}
var build_stage := 0
var respect := 0
var energy := 100
var health := 100
var wellbeing := 65
var cash := 12
var people := 4
var capacity := 0
var occupied_places := 0
var arrivals := 0
var choice := ""
var player := SAFE_START
var minutes := 0.0

# Persistent campaign fields are introduced here so later days can extend the same save.
var day := 1
var chapter := "Primeras redes"
var tents_built := 0
var active_commissions: Array = []
var completed_commissions: Dictionary = {}
var commission_history: Array = []
var mission_flags: Dictionary = {}
var negotiation_unlocked := false
var ending := ""

func all_talked() -> bool:
    return bool(talked.get("Alba", false)) and bool(talked.get("Joan", false)) and bool(talked.get("Mar", false))

func all_collected() -> bool:
    return bool(collected.get("lona", false)) and bool(collected.get("varillas", false)) and bool(collected.get("piquetas", false))

func resources() -> int:
    var total := 0
    for key in collected:
        if collected[key]:
            total += 1
    return total if build_stage == 0 else 0

func save_game() -> void:
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f == null:
        return
    var data := {
        "version": SAVE_VERSION, "phase": phase, "talked": talked, "collected": collected,
        "build_stage": build_stage, "respect": respect, "energy": energy, "health": health,
        "wellbeing": wellbeing, "cash": cash, "people": people, "capacity": capacity,
        "occupied_places": occupied_places,
        "arrivals": arrivals, "choice": choice, "x": player.x, "y": player.y, "minutes": minutes,
        "day": day, "chapter": chapter, "tents_built": tents_built,
        "active_commissions": active_commissions, "completed_commissions": completed_commissions,
        "commission_history": commission_history, "mission_flags": mission_flags,
        "negotiation_unlocked": negotiation_unlocked, "ending": ending
    }
    f.store_string(JSON.stringify(data))
    f.close()

func load_game() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return false
    var d = JSON.parse_string(f.get_as_text())
    f.close()
    if not d is Dictionary:
        return false
    var version := int(d.get("version", 0))
    if version < 1 or version > SAVE_VERSION:
        return false

    phase = str(d.get("phase", "talk"))
    if phase not in ["talk", "meeting", "materials", "build", "residents", "organization", "finished"]:
        phase = "talk"
    var saved_talked = d.get("talked", talked)
    if saved_talked is Dictionary:
        talked = saved_talked
    var saved_collected = d.get("collected", collected)
    if saved_collected is Dictionary:
        collected = saved_collected
    for key in ["Alba", "Joan", "Mar"]:
        if not talked.has(key):
            talked[key] = false
    for key in ["lona", "varillas", "piquetas"]:
        if not collected.has(key):
            collected[key] = false

    build_stage = clampi(int(d.get("build_stage", 0)), 0, 4)
    respect = maxi(0, int(d.get("respect", 0)))
    energy = clampi(int(d.get("energy", 100)), 0, 100)
    health = clampi(int(d.get("health", 100)), 0, 100)
    wellbeing = clampi(int(d.get("wellbeing", 65)), 0, 100)
    cash = maxi(0, int(d.get("cash", 12)))
    people = maxi(0, int(d.get("people", 4)))
    capacity = maxi(0, int(d.get("capacity", 0)))
    arrivals = clampi(int(d.get("arrivals", 0)), 0, 2)
    occupied_places = clampi(int(d.get("occupied_places", mini(arrivals, capacity))), 0, capacity)
    choice = str(d.get("choice", ""))
    minutes = maxf(0.0, float(d.get("minutes", 0)))

    # Version 1 stored coordinates in the old 1280x720 map. Preserve progress,
    # but never transplant those coordinates into the enlarged plaza.
    if version == 1:
        player = SAFE_START
        day = 1
        chapter = "Primeras redes"
        tents_built = 1 if build_stage >= 4 else 0
        active_commissions = ["organizacion"] if phase in ["organization", "finished"] else []
        completed_commissions = {}
        commission_history = []
        mission_flags = {"legacy_day1": true}
        negotiation_unlocked = respect >= 1000
        ending = ""
    else:
        player = Vector2(float(d.get("x", SAFE_START.x)), float(d.get("y", SAFE_START.y)))
        day = clampi(int(d.get("day", 1)), 1, 5)
        chapter = str(d.get("chapter", "Primeras redes"))
        tents_built = clampi(int(d.get("tents_built", 0)), 0, 24)
        var saved_active = d.get("active_commissions", [])
        if saved_active is Array:
            active_commissions = saved_active
        var saved_completed = d.get("completed_commissions", {})
        if saved_completed is Dictionary:
            completed_commissions = saved_completed
        var saved_history = d.get("commission_history", [])
        if saved_history is Array:
            commission_history = saved_history
        var saved_flags = d.get("mission_flags", {})
        if saved_flags is Dictionary:
            mission_flags = saved_flags
        negotiation_unlocked = bool(d.get("negotiation_unlocked", respect >= 1000)) or respect >= 1000
        ending = str(d.get("ending", ""))
        if build_stage >= 4:
            tents_built = maxi(tents_built, 1)
    return true

func reset_save() -> void:
    if FileAccess.file_exists(SAVE_PATH):
        DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
