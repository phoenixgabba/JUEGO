extends RefCounted
class_name CampWorld

const PLAZA = preload("res://assets/acampada/valencia_pixel_map_topdown_pixel.png")
const PLAYER = preload("res://assets/acampada/player.png")
const ALBA = preload("res://assets/acampada/alba.png")
const JOAN = preload("res://assets/acampada/joan.png")
const MAR = preload("res://assets/acampada/mar.png")
const TARP = preload("res://assets/acampada/tarp.png")
const POLES = preload("res://assets/acampada/poles.png")
const PEGS = preload("res://assets/acampada/pegs.png")
const TABLE = preload("res://assets/acampada/table.png")
const TENT = preload("res://assets/acampada/tent.png")
const LAID = preload("res://assets/acampada/tent_laid.png")
const FRAMED = preload("res://assets/acampada/tent_poles.png")
const RAISED = preload("res://assets/acampada/tent_raised.png")
const FONT = preload("res://assets/template/fonts/ui_bold.tres")

const WORLD_WIDTH := 2304.0
const WORLD_HEIGHT := 1536.0
const WORLD_SIZE := Vector2(WORLD_WIDTH, WORLD_HEIGHT)
const SAFE_START := Vector2(1152, 1320)
const MEETING := Vector2(1152, 1030)
const SITE := Vector2(780, 640)
const ORGANIZATION := Vector2(1760, 1110)
const FOUNTAIN := Vector2(2135, 850)
const MATERIALS := {"lona": Vector2(820, 925), "varillas": Vector2(1375, 920), "piquetas": Vector2(1100, 1100)}
const PLAYER_CLEARANCE := 18.0
const BUILD_CLEARANCE := 12.0
# World-space hitboxes are separate from the illustration. These cover the
# larger visible tree beds and benches while leaving the central crossing open.
const DECORATION_COLLIDERS := [
	Rect2(250, 318, 70, 60), Rect2(445, 318, 120, 60), Rect2(705, 318, 95, 60),
	Rect2(1360, 318, 110, 60), Rect2(1640, 318, 110, 60), Rect2(1845, 318, 85, 60),
	Rect2(220, 485, 95, 72), Rect2(360, 485, 115, 72), Rect2(495, 485, 90, 72),
	Rect2(615, 485, 115, 72), Rect2(800, 485, 108, 72), Rect2(930, 485, 70, 72),
	Rect2(1320, 485, 135, 72), Rect2(1510, 485, 120, 72), Rect2(1700, 485, 90, 72),
	Rect2(1890, 485, 125, 72),
	Rect2(210, 645, 65, 150), Rect2(210, 845, 65, 190),
	Rect2(1810, 620, 65, 150), Rect2(1810, 820, 65, 190),
	Rect2(210, 1150, 110, 70), Rect2(360, 1150, 155, 70), Rect2(550, 1150, 170, 70),
	Rect2(755, 1150, 140, 70), Rect2(1410, 1150, 120, 70), Rect2(1560, 1150, 160, 70),
	Rect2(1750, 1150, 130, 70), Rect2(1910, 1150, 200, 70)
]

# This ordered list grows the visible camp from the first B-zone shelter. Paths
# remain broad, and each footprint keeps a clear outside approach.
const CAMP_SITES := [
	Vector2(780, 640), Vector2(620, 500), Vector2(780, 500), Vector2(620, 780),
	Vector2(360, 920), Vector2(510, 920), Vector2(360, 1110), Vector2(510, 1110),
	Vector2(1400, 440), Vector2(1560, 440), Vector2(1400, 600), Vector2(1560, 600),
	Vector2(1790, 1080), Vector2(1940, 1080), Vector2(1790, 1260), Vector2(1940, 1260)
]

const ZONES := [
	{"name":"B", "pos":Vector2(500, 430)},
	{"name":"A", "pos":Vector2(1700, 505)},
	{"name":"C", "pos":Vector2(265, 1035)},
	{"name":"E", "pos":Vector2(270, 1255)},
	{"name":"D", "pos":Vector2(1850, 1260)},
	{"name":"H · PLAZA 15M", "pos":Vector2(1740, 940)}
]
const STATIONS := [
	{"name":"REDES", "pos":Vector2(435, 640)},
	{"name":"RECURSOS", "pos":Vector2(1152, 440)},
	{"name":"COCINA", "pos":Vector2(1152, 635)},
	{"name":"SEGURIDAD", "pos":Vector2(1152, 830)},
	{"name":"RECOGIDA", "pos":Vector2(1152, 1030)},
	{"name":"PUNTO VIOLETA", "pos":Vector2(1760, 420)},
	{"name":"MÉDICO", "pos":Vector2(1935, 435)},
	{"name":"CULTURA", "pos":Vector2(1815, 570)},
	{"name":"INFORMACIÓN", "pos":Vector2(1152, 1440)}
]

func resident_target(index: int) -> Vector2:
	return SITE + Vector2(-24.0 + float(index) * 48.0, 75.0)

func npc_pos(n: String, s: CampState, t: float) -> Vector2:
	var p := SAFE_START
	match n:
		"Alba": p = Vector2(1030, 1240)
		"Joan": p = Vector2(1050, 1100)
		"Mar": p = Vector2(1310, 1240)
	if s.phase == "meeting":
		match n:
			"Alba": p = MEETING + Vector2(-80, 38)
			"Joan": p = MEETING + Vector2(0, -24)
			"Mar": p = MEETING + Vector2(82, 38)
	elif s.phase in ["build", "residents", "organization", "finished"]:
		match n:
			"Alba": p = Vector2(690, 830)
			"Joan": p = Vector2(360, 660)
			"Mar": p = Vector2(1580, 1110)
	# Gentle routines are visual-only; they never change collision or task state.
	if s.phase not in ["talk", "meeting"]:
		var shift := 0.0
		match n:
			"Alba": shift = 0.4
			"Joan": shift = 2.1
			"Mar": shift = 4.0
		p += Vector2(sin(t * 0.42 + shift) * 18.0, cos(t * 0.35 + shift) * 7.0)
	return p

func is_walkable(p: Vector2, s: CampState) -> bool:
	if p.x < 95 or p.x > WORLD_WIDTH - 95 or p.y < 340 or p.y > WORLD_HEIGHT - 60:
		return false
	# City Hall has an independent rectangular hitbox; no collision is inferred from its art.
	if Rect2(350, 0, 1600, 285).has_point(p): return false
	# Circular basin and raised rim; the rest of H stays open for passage.
	var fountain_delta := (p - FOUNTAIN) / Vector2(200, 175)
	if fountain_delta.length() < 1.0: return false
	for blocker: Rect2 in DECORATION_COLLIDERS:
		if blocker.grow(PLAYER_CLEARANCE).has_point(p): return false
	var count := maxi(s.tents_built, 1 if s.build_stage >= 4 else 0)
	for i in range(mini(count, CAMP_SITES.size())):
		if tent_footprint(CAMP_SITES[i]).grow(PLAYER_CLEARANCE).has_point(p): return false
	return true

func tent_footprint(site: Vector2) -> Rect2:
	return Rect2(site.x - 72, site.y - 54, 144, 108)

func can_build_at(site: Vector2, s: CampState, actor_positions: Array = []) -> bool:
	if s.build_stage > 0 or not is_walkable(site, s): return false
	var footprint := tent_footprint(site)
	if not _footprint_clear(footprint, s): return false
	for actor_pos in actor_positions:
		if actor_pos is Vector2 and footprint.grow(24).has_point(actor_pos): return false
	# Keep three distinct outside exits open; the entrance is from the south.
	for exit in [site + Vector2(0, 122), site + Vector2(-122, 0), site + Vector2(122, 0)]:
		if not is_walkable(exit, s): return false
	return true

func _footprint_clear(footprint: Rect2, s: CampState) -> bool:
	var expanded := footprint.grow(BUILD_CLEARANCE)
	if expanded.intersects(Rect2(350, 0, 1600, 285)): return false
	if expanded.intersects(Rect2(FOUNTAIN - Vector2(200, 175), Vector2(400, 350))): return false
	for blocker: Rect2 in DECORATION_COLLIDERS:
		if expanded.intersects(blocker.grow(BUILD_CLEARANCE)): return false
	var count := maxi(s.tents_built, 1 if s.build_stage >= 4 else 0)
	for i in range(mini(count, CAMP_SITES.size())):
		if expanded.intersects(tent_footprint(CAMP_SITES[i]).grow(BUILD_CLEARANCE)): return false
	return true

func safe_spawn(origin: Vector2, s: CampState) -> Vector2:
	var candidates := [
		origin + Vector2(0, 132), origin + Vector2(0, -132),
		origin + Vector2(-132, 0), origin + Vector2(132, 0), SAFE_START
	]
	for candidate in candidates:
		if is_walkable(candidate, s): return candidate
	# The starting access is intentionally kept clear in every camp state.
	return SAFE_START

func draw(c: Control, s: CampState, rect: Rect2, camera_origin: Vector2, zoom: float, t: float, walking: bool, arrival_positions: Array) -> void:
	c.draw_rect(rect, Color("d4c2a0"), true)
	var draw_origin := rect.position - camera_origin * zoom
	c.draw_set_transform(draw_origin, 0.0, Vector2.ONE * zoom)
	var world_rect := Rect2(Vector2.ZERO, WORLD_SIZE)
	var visible := Rect2(camera_origin, rect.size / zoom).grow(140)
	# The plaza illustration is the base layer. Buildings, the player and tents
	# remain separate, world-space objects with their own footprints.
	c.draw_texture_rect(PLAZA, world_rect, false)

	for zone in ZONES:
		var p: Vector2 = zone.pos
		if visible.has_point(p): _draw_badge(c, p, str(zone.name), 17, Color("2b5148"))
	for station in STATIONS:
		var p: Vector2 = station.pos
		if visible.has_point(p): _draw_station(c, p, str(station.name), zoom)

	for i in range(mini(s.tents_built, CAMP_SITES.size())):
		var p: Vector2 = CAMP_SITES[i]
		if visible.intersects(Rect2(p - Vector2(100, 100), Vector2(200, 190))):
			c.draw_texture_rect(TENT, Rect2(p - Vector2(88, 76), Vector2(176, 150)), false)
	if s.build_stage > 0 and s.tents_built == 0:
		var build_tex: Texture2D = LAID
		if s.build_stage == 2: build_tex = FRAMED
		if s.build_stage == 3: build_tex = RAISED
		if s.build_stage >= 4: build_tex = TENT
		c.draw_texture_rect(build_tex, Rect2(SITE - Vector2(88, 76), Vector2(176, 150)), false)

	if s.phase in ["organization", "finished"]:
		c.draw_texture_rect(TABLE, Rect2(ORGANIZATION - Vector2(42, 45), Vector2(84, 82)), false)
		if s.phase == "organization": _draw_marker(c, ORGANIZATION, "ORGANIZACIÓN", t, zoom)
	if s.phase == "meeting": _draw_marker(c, MEETING, "ASAMBLEA", t, zoom)
	if s.phase == "build": _draw_marker(c, SITE, "MONTAR", t, zoom)

	if s.phase == "materials":
		for k in MATERIALS:
			if not s.collected[k]:
				var texture: Texture2D = TARP if k == "lona" else (POLES if k == "varillas" else PEGS)
				var p: Vector2 = MATERIALS[k]
				c.draw_circle(p, 29, Color(1.0, 0.84, 0.40, 0.27))
				c.draw_texture_rect(texture, Rect2(p - Vector2(30, 34), Vector2(60, 60)), false)
				c.draw_string(FONT, p + Vector2(-52, 48), str(k).to_upper(), HORIZONTAL_ALIGNMENT_CENTER, 104, maxi(11, roundi(14.0 / zoom)), Color("263e39"))

	# Depth-sort residents, NPCs and player on their feet; presentation culling
	# does not pause their tasks or affect their collision state.
	var actors: Array = []
	for n in ["Alba", "Joan", "Mar"]:
		var npos := npc_pos(n, s, t)
		if visible.has_point(npos):
			var tex: Texture2D = ALBA if n == "Alba" else (JOAN if n == "Joan" else MAR)
			actors.append({"name":n, "pos":npos, "tex":tex})
	if visible.has_point(s.player): actors.append({"name":"Tú", "pos":s.player, "tex":PLAYER, "walking":walking})
	for i in range(arrival_positions.size()):
		var pos: Vector2 = arrival_positions[i]
		if visible.has_point(pos): actors.append({"name":"Vecina" if i == 0 else "Vecino", "pos":pos, "tex":MAR if i == 0 else JOAN, "walking":s.phase == "residents"})
	actors.sort_custom(func(a, b): return a.pos.y < b.pos.y)
	for actor_data in actors:
		_draw_actor(c, actor_data.tex, actor_data.pos, str(actor_data.name), t, zoom, bool(actor_data.get("walking", s.phase not in ["talk", "meeting"])))
	c.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)

func _draw_badge(c: Control, pos: Vector2, label: String, font_size: int, fill: Color) -> void:
	var width := 38.0 if label.length() == 1 else 186.0
	var rect := Rect2(pos.x, pos.y, width, 29)
	c.draw_rect(rect.grow(3), Color(0.08, 0.13, 0.12, 0.34), true)
	c.draw_rect(rect, Color(fill.r, fill.g, fill.b, 0.91), true)
	c.draw_string(FONT, pos + Vector2(9, 21), label, HORIZONTAL_ALIGNMENT_LEFT, width - 16, font_size, Color("fff4d7"))

func _draw_station(c: Control, pos: Vector2, label: String, zoom: float) -> void:
	var font_size := maxi(13, roundi(17.0 / zoom))
	c.draw_circle(pos, 10, Color("fff1c7"))
	c.draw_circle(pos, 5, Color("bd734b"))
	c.draw_string(FONT, pos + Vector2(15, 6), label, HORIZONTAL_ALIGNMENT_LEFT, 220, font_size, Color("263d35"))

func _draw_marker(c: Control, pos: Vector2, label: String, t: float, zoom: float) -> void:
	var radius := 26.0 + sin(t * 3.0) * 3.0
	c.draw_arc(pos, radius, 0, TAU, 40, Color("ffed9c"), 4.0)
	c.draw_circle(pos, 5, Color("fff5cb"))
	var font_size := maxi(13, roundi(15.0 / zoom))
	c.draw_rect(Rect2(pos.x - 85, pos.y - 88, 170, 28), Color(0.13, 0.24, 0.21, 0.90), true)
	c.draw_string(FONT, pos + Vector2(-81, -68), label, HORIZONTAL_ALIGNMENT_CENTER, 162, font_size, Color("fff0bb"))

func _draw_ellipse(c: Control, pos: Vector2, radii: Vector2, color: Color) -> void:
	var points := PackedVector2Array()
	for i in range(24):
		var angle := TAU * float(i) / 24.0
		points.append(pos + Vector2(cos(angle) * radii.x, sin(angle) * radii.y))
	c.draw_colored_polygon(points, color)

func _draw_actor(c: Control, tex: Texture2D, pos: Vector2, name: String, t: float, zoom: float, moving: bool) -> void:
	_draw_ellipse(c, pos + Vector2(0, 1), Vector2(22, 9), Color(0.16, 0.14, 0.10, 0.28))
	var bob := sin(t * 9.0 + pos.x) * 2.0 if moving else sin(t * 1.7 + pos.x) * 0.6
	c.draw_texture_rect(tex, Rect2(pos + Vector2(-30, -91 + bob), Vector2(60, 92)), false)
	var font_size := maxi(13, roundi(13.0 / zoom))
	c.draw_rect(Rect2(pos.x - 40, pos.y - 116 + bob, 80, 21), Color(0.11, 0.19, 0.17, 0.83), true)
	c.draw_string(FONT, pos + Vector2(-37, -100 + bob), name, HORIZONTAL_ALIGNMENT_CENTER, 74, font_size, Color("fff9e8"))
