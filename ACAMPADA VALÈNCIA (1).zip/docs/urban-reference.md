# Referencias urbanas para el mapa

La plaza real tiene una forma triangular, una fuente circular y edificios cívicos e históricos dominantes en su perímetro. El mundo del juego mantiene la fachada del Ayuntamiento en el borde superior, la fuente hacia la derecha según el croquis y una zona de plaza abierta para recorrer. La fuente y los edificios tienen hitboxes propias; su arte no define la colisión.

La ubicación A/B/C/D/E/H, las filas de carpas y los puntos de las comisiones son la distribución final fijada por el croquis del juego. No pretenden describir la organización histórica de la plaza real. Las comisiones que no caben en el dibujo pueden operar sin carpa.

Northleg describe la plaza actual como triangular, menciona la fuente circular y sitúa la arquitectura municipal e histórica en el perímetro [1]. World Design Organization documenta el uso de la plaza como espacio público de actividades, talleres, exhibiciones y encuentros comunitarios [2]. La página municipal de València describe las propuestas de reurbanización, mantiene como elementos esenciales la explanada para actos públicos y sitúa la fuente y el monumento como referencias dentro de la plaza [3]. Visit Valencia describe el Ayuntamiento como un conjunto de dos estructuras con una fachada monumental hacia la plaza [4].

## Referencias

[1]: https://en.northleg.com/valencia/attractions/plaza-ayuntamiento/ "Plaza del Ayuntamiento, Northleg"
[2]: https://wdo.org/agora-valencia-the-pavilion-of-world-design-capital-valencia-2022-opens-its-doors-to-the-public-in-the-plaza-del-ayuntamiento/ "Agora Valencia, World Design Organization"
[3]: https://www.valencia.es/cas/actualidad/-/content/paneles-proyectos-finalistas-plaza-ayuntamiento "Propuestas para la plaza del Ayuntamiento, Ayuntamiento de València"
[4]: https://www.visitvalencia.com/en/what-to-do-valencia/valencian-culture/monuments-in-valencia/city-hall "Valencia City Hall, Visit Valencia"
