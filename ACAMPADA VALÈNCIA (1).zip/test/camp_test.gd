extends SceneTree

func _initialize() -> void:
	call_deferred("run")

func check(value: bool, label: String) -> void:
	if not value:
		push_error("FAIL: " + label)
		quit(1)
		assert(value, label)

func reachable_target_count(world, state, start: Vector2, targets: Array, step: int = 16) -> int:
	var columns := int(world.WORLD_WIDTH / step) + 1
	var rows := int(world.WORLD_HEIGHT / step) + 1
	var pending: Dictionary = {}
	for target in targets:
		var cell := Vector2i(roundi(target.x / float(step)), roundi(target.y / float(step)))
		pending[cell.y * columns + cell.x] = true
	var target_count := pending.size()
	var start_cell := Vector2i(roundi(start.x / float(step)), roundi(start.y / float(step)))
	var start_index := start_cell.y * columns + start_cell.x
	var queue := PackedInt32Array([start_index])
	var visited := PackedByteArray()
	visited.resize(columns * rows)
	visited[start_index] = 1
	var found := 0
	var head := 0
	while head < queue.size() and found < target_count:
		var index := queue[head]
		head += 1
		if pending.has(index):
			pending.erase(index)
			found += 1
		var x := index % columns
		var y := int(index / columns)
		var neighbors: Array[int] = []
		if x > 0: neighbors.append(index - 1)
		if x < columns - 1: neighbors.append(index + 1)
		if y > 0: neighbors.append(index - columns)
		if y < rows - 1: neighbors.append(index + columns)
		for next_index in neighbors:
			if visited[next_index] != 0: continue
			var point := Vector2(float(next_index % columns * step), float(int(next_index / columns) * step))
			if world.is_walkable(point, state):
				visited[next_index] = 1
				queue.append(next_index)
	return found

func run() -> void:
	var main = (load("res://scenes/main.tscn") as PackedScene).instantiate()
	root.add_child(main)
	await process_frame
	main.start_game(false)
	main.close_dialog()
	check(main.s.phase == "talk", "inicio de campaña en una plaza casi vacía")
	check(main.world.is_walkable(main.s.player, main.s), "punto inicial en suelo transitable")
	check(main.world.WORLD_SIZE.x > 1280 and main.world.WORLD_SIZE.y > 720, "mapa mayor que la cámara")
	for blocker: Rect2 in main.world.DECORATION_COLLIDERS:
		var blocker_center := blocker.position + blocker.size * 0.5
		check(not main.world.is_walkable(blocker_center, main.s), "hitbox decorativa bloquea el centro del obstáculo")
	check(not main.world.can_build_at(main.world.DECORATION_COLLIDERS[0].get_center(), main.s), "no se construye sobre jardineras/bancos")
	var safe_from_decoration: Vector2 = main.world.safe_spawn(main.world.DECORATION_COLLIDERS[0].get_center(), main.s)
	check(main.world.is_walkable(safe_from_decoration, main.s), "safe_spawn reubica desde una hitbox decorativa")
	var route_targets: Array = [
		main.world.MEETING, main.world.MATERIALS["lona"], main.world.MATERIALS["varillas"], main.world.MATERIALS["piquetas"],
		main.world.npc_pos("Alba", main.s, main.elapsed), main.world.npc_pos("Joan", main.s, main.elapsed), main.world.npc_pos("Mar", main.s, main.elapsed),
		main.world.SITE + Vector2(0, 122), main.world.ORGANIZATION, Vector2(1740, 940), Vector2(1920, 850), Vector2(2135, 1050),
		Vector2(1152, 450), Vector2(1152, 900)
	]
	for target in route_targets:
		check(main.world.is_walkable(target, main.s), "punto de ruta en suelo transitable: " + str(target))
	check(reachable_target_count(main.world, main.s, main.world.SAFE_START, route_targets) == route_targets.size(), "rutas desde el acceso a NPC, materiales, eje central, D, H y alrededor de la fuente")
	var y_before: float = main.s.player.y
	Input.action_press("move_up")
	main._process(0.2)
	Input.action_release("move_up")
	check(main.s.player.y < y_before, "movimiento por teclado en el mapa ampliado")
	var x_before: float = main.s.player.x
	main.clickables = [{"rect":Rect2(0,0,100,100), "id":"dir", "dir":Vector2.RIGHT}]
	main.pointer_down(Vector2(50,50), 0)
	main._process(0.2)
	main.pointer_up(Vector2(50,50), 0)
	check(main.s.player.x > x_before and main.touch_directions.is_empty(), "movimiento táctil y liberación")
	for n in ["Alba", "Joan", "Mar"]:
		main.s.player = main.world.npc_pos(n, main.s, main.elapsed) + Vector2(0, 50)
		main.interact()
		check(main.s.talked[n], "conversación con " + n)
		main.close_dialog()
	check(main.s.phase == "meeting", "reunión tras conocer a las tres personas")
	main.s.player = main.world.MEETING + Vector2(0,60)
	main.interact()
	check(main.choosing, "la asamblea ofrece una decisión")
	main.choose_assembly(0)
	main.close_dialog()
	check(main.s.phase == "materials" and main.s.choice == "cuidados", "el acuerdo cambia el estado")
	for k in ["lona", "varillas", "piquetas"]:
		main.s.player = main.world.MATERIALS[k] + Vector2(0,30)
		main.interact()
		check(main.s.collected[k], "recogida de " + k)
		if main.dialogue: main.close_dialog()
	check(main.s.phase == "build", "materiales habilitan el montaje")
	check(not main.world.can_build_at(main.world.SITE, main.s, [main.world.SITE]), "no construir sobre un personaje")
	check(main.world.can_build_at(main.world.SITE, main.s, [main.world.SITE + Vector2(0,180)]), "sitio despejado y accesible")
	main.s.player = main.world.SITE + Vector2(0,75)
	main.interact()
	check(main.mini and main.s.build_stage == 0, "inicia el minijuego de montaje")
	main.mini_rect = Rect2(0,0,820,500)
	main.pointer_down(Vector2(240,235), 7)
	var drag := InputEventScreenDrag.new()
	drag.position = Vector2(560,235)
	main._input(drag)
	main.pointer_up(Vector2(560,235), 7)
	check(main.s.build_stage == 1 and not main.mini, "lona arrastrada y extendida")
	main.close_dialog(); main.interact()
	main.elapsed = 0
	main.mini_action(); main.mini_action()
	check(main.s.build_stage == 2, "varillas encajadas con precisión")
	main.close_dialog(); main.interact()
	main.action_held = true
	main._process(2.1)
	check(main.s.build_stage == 3, "estructura levantada al mantener")
	main.close_dialog(); main.interact()
	for i in range(4):
		main.mini_selected = i
		main.mini_action()
	check(main.s.build_stage == 4 and main.s.capacity == 2 and main.s.tents_built == 1, "cuatro piquetas y tienda terminada")
	check(main.s.people == 4 and main.s.occupied_places == 0, "la tienda aporta capacidad sin crear residentes")
	for i in range(2):
		var resident_target: Vector2 = main.world.resident_target(i)
		check(main.world.is_walkable(resident_target, main.s) and not main.world.tent_footprint(main.world.SITE).grow(main.world.PLAYER_CLEARANCE).has_point(resident_target), "plaza de llegada libre junto a la tienda")
	check(main.world.is_walkable(main.s.player, main.s), "reubicación segura tras construir")
	check(main.s.player == main.world.safe_spawn(main.world.SITE, main.s) and not main.world.tent_footprint(main.world.SITE).grow(main.world.PLAYER_CLEARANCE).has_point(main.s.player), "safe_spawn deja al jugador fuera de la tienda")
	for exit in [main.world.SITE + Vector2(0,122), main.world.SITE + Vector2(-122,0), main.world.SITE + Vector2(122,0), main.world.SITE + Vector2(0,-122)]:
		check(main.world.is_walkable(exit, main.s), "salida libre de tienda: " + str(exit))
	check(not main.world.is_walkable(main.world.SITE, main.s), "huella de tienda bloqueada tras construir")
	main.close_dialog()
	for i in range(240): main.update_arrivals(0.1)
	check(main.s.arrivals == 2 and main.s.people == 6 and main.s.occupied_places == main.s.capacity and main.s.phase == "organization", "residentes llegan caminando y ocupan el aforo")
	main.s.player = main.world.ORGANIZATION + Vector2(0,45)
	main.interact()
	check(main.s.phase == "finished" and main.dialogue_next == "show_end", "Organización provisional en D junto a H")
	main.close_dialog()
	check(main.screen == "result", "pantalla de fin del Día 1")
	var loaded = load("res://scripts/camp/state.gd").new()
	check(loaded.load_game() and loaded.phase == "finished" and loaded.people == 6 and loaded.occupied_places == 2, "guardado y recuperación v3")
	var old_v2_file := FileAccess.open(loaded.SAVE_PATH, FileAccess.WRITE)
	old_v2_file.store_string(JSON.stringify({"version":2,"phase":"finished","build_stage":4,"respect":110,"people":6,"capacity":2,"arrivals":2,"x":640,"y":620}))
	old_v2_file.close()
	var migrated_v2 = load("res://scripts/camp/state.gd").new()
	check(migrated_v2.load_game() and migrated_v2.occupied_places == 2, "migración de guardado v2 infiere las plazas ocupadas")

	# Emulate the inherited save format and ensure migration moves the player to safe ground.
	var old_file := FileAccess.open(loaded.SAVE_PATH, FileAccess.WRITE)
	old_file.store_string(JSON.stringify({"version":1,"phase":"finished","build_stage":4,"respect":110,"people":6,"capacity":2,"arrivals":2,"x":640,"y":620}))
	old_file.close()
	var migrated = load("res://scripts/camp/state.gd").new()
	check(migrated.load_game() and migrated.player == migrated.SAFE_START and migrated.tents_built == 1 and migrated.occupied_places == 2, "migración del guardado heredado al mapa nuevo")
	check(main.world.is_walkable(migrated.player, migrated), "migración fuera de obstáculos")
	migrated.reset_save()
	print("[acampada-tests] PASS: Día 1, mapa/cámara, colisiones, construcción, llegadas/aforo, guardados v1-v3 y migración")
	quit(0)
